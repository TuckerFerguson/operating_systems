#include <unistd.h>
int main(){for(;;){sleep(1000);}}
