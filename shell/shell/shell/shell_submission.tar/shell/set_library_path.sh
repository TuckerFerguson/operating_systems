#!/bin/bash
echo "Run me with \$('./set_library_path.sh')"
echo export LD_LIBRARY_PATH=`pwd`:$LD_LIBRARY_PATH