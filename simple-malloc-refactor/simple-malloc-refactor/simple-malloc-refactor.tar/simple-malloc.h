
#ifndef __SIMPLE_MALLOC_H
#define __SIMPLE_MALLOC_H

/*
 * Slightly modified version from K&R Section 8.7 
 */

#include <unistd.h>
#include <stdlib.h>

#define MINIMUM_NUMBER_OF_UNITS 1024
#define NO_MEMORY_LEFT NULL

typedef double Align; /* for alignment to long boundary */

union header {
	struct {
		union header *next_free_block;
		unsigned size;
	} metadata;
	Align alignment_value;
};

typedef union header Header;

void *simple_malloc(unsigned number_of_requested_bytes);
void simple_free(void *ap);
void print_free_list();

static void format_memory_and_add_to_free_list(void* raw_memory, int number_of_units);
static int reached_end_of_free_list(Header* current_block);
static void* get_memory_location_from_block(Header* current_block);
static Header* allocate_block(Header* current_block, int number_of_units_to_allocate);
static int current_block_is_large_enough(int current_block_size, int number_of_units);
static int bytes_to_number_of_units(int);
static void initialize_list(Header* previous_block);
static Header* find_available_insertion_point(Header* memory_to_free);
static int should_combine_with_upper_neighbour(Header* block_to_free, Header* insertion_block);
static void combine_with_upper_neighbour(Header* block_to_free, Header* insertion_point);
static int should_combine_with_lower_neighbour(Header* block_to_free, Header* insertion_point);
static void combine_with_lower_neighbour(Header* block_to_free, Header* insertion_point);
static Header *get_more_memory_from_os(unsigned);

#endif
